#include<unistd.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define MAX  1000
int main(){
	int fd[2];
	char buf[MAX];
	pid_t pid;
	int len;
	if(pipe(fd)<0)
	{
		perror("failed to pipe\n");
		exit(1);
	}
	if((pid=fork())<0)
	{
		perror("failed to fork\n");
		exit(1);
	}
	else if(pid>0)
	{
		printf("father write sucess\n");
		write(fd[1],"success\n",MAX);
		sleep(1);
		read(fd[0],buf,MAX);
		printf("father read content: %s\n",buf);
		exit(0);
	}
	else
	{
		printf("child read from pipe\n");
		read(fd[0],buf,MAX);
		printf("child write reply to pipe\n");
		write(fd[1],"data\n",MAX);
	}
	return 0;
}


