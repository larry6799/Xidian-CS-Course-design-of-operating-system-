#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <wait.h>

void process()
{
	printf("child process---%d\n",getpid());
}

int main()
{
	signal(SIGUSR2,process);
	pid_t pid;
	pid=fork();
	if(pid==0){
		printf("...child process start...\n");
		printf("send a signal:%d\n",getpid());
		kill(getppid(),SIGUSR2);
		printf("...child process finished...\n");
		exit(0);
	}
	else if(pid>0){	
		printf("...father process start...\n");
	        printf("receive a signal %d from child \n father:%d\n",pid,getpid());
		waitpid(pid,NULL,0);
		printf("...father process finished...\n");
	}
	else{
		printf("ERROR\n");
	}
 
	return 0;
}


