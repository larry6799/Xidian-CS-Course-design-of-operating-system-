#include<sys/ipc.h>
#include<sys/shm.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct people{
	char name[6];
	int age;
};
int main(int argc,char **argv)
{
	struct people *p;
	int key=ftok(".",1);
	if(key==0){
		printf("Failed to create key value!\n");
	}
	else{
		int shm_id=shmget(key,4096,0666|IPC_CREAT);
		p=shmat(shm_id,NULL,7);
		printf("%s\n",p->name);
		printf("%d\n",p->age);
		shmdt(p);
	}
	return 0;
}
