#include<stdio.h>
#include <unistd.h>
#include <semaphore.h>
#include <pthread.h>
#include<string.h>
#include<stdlib.h>
#include<sys/sem.h>
union semun{
int val;
struct semid_ds *buf;
unsigned short *array;
};
int fullSEG,emptySEG,mutex;
int semaphore_p(int semId);
int semaphore_v(int semId);
int setValue(int semId,int value);
int i;
int main(){
fullSEG = semget((key_t)1234, 1, 0666 | IPC_CREAT);
setValue(fullSEG, 0);
emptySEG = semget((key_t)1235, 1, 0666 | IPC_CREAT);
setValue(emptySEG, 6);
mutex = semget((key_t)1236, 1, 0666 | IPC_CREAT);
setValue(mutex, 1);
pid_t customerOne, customerTwo;
for(i = 0; i < 2; i++){
pid_t temp = fork();
if(temp == 0) {
if(i == 0) customerOne = getpid();
if(i == 1) customerTwo = getpid();
break;
}
}
if(getpid() == customerOne){
while(1){
sleep(3);
semaphore_p(fullSEG);
semaphore_p(mutex);
int value = semctl(fullSEG, 0, GETVAL, 0);
printf("Customer %d: use 1 thing, now there are %d things\n", getpid(), value);
semaphore_v(mutex);
semaphore_v(emptySEG);
}
}
else if(getpid() == customerTwo) {
while(1){
sleep(3);
semaphore_p(fullSEG);
semaphore_p(mutex);
int value = semctl(fullSEG, 0, GETVAL, 0);
printf("Customer %d: use 1 thing, now there are %d things\n", getpid(), value);
semaphore_v(mutex);
semaphore_v(emptySEG);
}
}
else{
while(1){
sleep(1);
semaphore_p(emptySEG);
semaphore_v(fullSEG);
semaphore_p(mutex);
int value = semctl(fullSEG, 0, GETVAL, 0);
printf("Producer %d: produce 1 thing, now there are %d things\n", getpid(), value);
semaphore_v(mutex);
}
}
return 0;   
}
int semaphore_p(int semId){
struct sembuf sem_b;
sem_b.sem_num = 0;
sem_b.sem_op = -1;
sem_b.sem_flg = SEM_UNDO;
if(semop(semId, &sem_b, 1) == -1){
printf("semaphore_p failed\n");
}
return 0;
}
int semaphore_v(int semId){
struct sembuf sem_b;
sem_b.sem_num = 0;
sem_b.sem_op = 1;
sem_b.sem_flg = SEM_UNDO;
if(semop(semId, &sem_b, 1) == -1)
printf("semaphore_v failed\n");
return 0;
}
int setValue(int semId, int value){
union semun sem_union;
sem_union.val = value;
if(semctl(semId, 0, SETVAL, sem_union) == -1) printf("Setting %d value is error\n", semId);
return 0;
}
